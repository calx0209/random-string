from setuptools import setup

setup(
    name="rndstr",
    version='1.0',
    description='a random string generate',
    author='calx0209',
    url='https://github.com/calx0209/random-string',
)