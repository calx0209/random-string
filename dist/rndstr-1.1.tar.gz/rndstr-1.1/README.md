# random-string

This repository generate a random string.

## Dependency

* python 3.9.0

## Setup

1. Homebrew install
2. `brew install anyenv`

## Usage

```bash
$ python rndstr/app
```

## Demo

